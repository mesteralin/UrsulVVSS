package org.example.features;

import net.serenitybdd.junit.runners.SerenityRunner;
import net.thucydides.core.annotations.Managed;
import net.thucydides.core.annotations.Steps;
import org.example.steps.LoginSteps;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

@RunWith(SerenityRunner.class)
public class ScenarioTests {

    @Managed(driver = "chrome")
    WebDriver driver;

    @Steps
    LoginSteps login;

    @Test
    public void complete_user_flow_should_succeed() {
        // Login
        login.is_on_login_page();
        login.logs_in_with("standard_user", "secret_sauce");
        login.should_be_on_inventory_page();

        WebDriverWait wait = new WebDriverWait(driver, 10);

        // Add first product to cart (generic like Playwright)
        WebElement firstAddButton = wait.until(ExpectedConditions.elementToBeClickable(
                By.cssSelector("button[data-test^='add-to-cart']")));
        firstAddButton.click();

        // Verify cart badge is 1
        WebElement badge = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.className("shopping_cart_badge")));
        org.junit.Assert.assertEquals("1", badge.getText());

        try {
            Thread.sleep(2000); 
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        // Go to cart
        WebElement cartLink = wait.until(ExpectedConditions.elementToBeClickable(
                By.className("shopping_cart_link")));
        cartLink.click();
        wait.until(ExpectedConditions.urlContains("cart.html"));

        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        // Remove item
        WebElement removeButton = wait.until(ExpectedConditions.elementToBeClickable(
                By.cssSelector("button[data-test^='remove']")));
        removeButton.click();

        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        // Ensure cart is empty
        wait.until(ExpectedConditions.numberOfElementsToBe(
                By.className("cart_item"), 0));
        org.junit.Assert.assertEquals(0, driver.findElements(By.className("cart_item")).size());

        // Logout
        WebElement menuButton = wait.until(ExpectedConditions.elementToBeClickable(
                By.id("react-burger-menu-btn")));
        menuButton.click();

        WebElement logoutButton = wait.until(ExpectedConditions.elementToBeClickable(
                By.id("logout_sidebar_link")));
        logoutButton.click();

        wait.until(ExpectedConditions.urlToBe("https://www.saucedemo.com/"));
        org.junit.Assert.assertEquals("https://www.saucedemo.com/", driver.getCurrentUrl());
    }
}