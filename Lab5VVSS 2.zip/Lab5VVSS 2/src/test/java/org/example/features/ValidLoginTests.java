package org.example.features;

import net.serenitybdd.junit.runners.SerenityParameterizedRunner;
import net.thucydides.junit.annotations.UseTestDataFrom;
import net.thucydides.core.annotations.Managed;
import net.thucydides.core.annotations.Steps;
import org.example.steps.LoginSteps;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.openqa.selenium.WebDriver;

@RunWith(SerenityParameterizedRunner.class)
@UseTestDataFrom("src/test/resources/valid-logins.csv")
public class ValidLoginTests {

    @Managed(driver = "chrome")
    WebDriver driver;

    @Steps
    LoginSteps login;

    public String username;
    public String password;

    @Test
    public void should_login_successfully_with_valid_credentials() {
        login.is_on_login_page();
        login.logs_in_with(username, password);
        login.should_be_on_inventory_page();
    }
}
