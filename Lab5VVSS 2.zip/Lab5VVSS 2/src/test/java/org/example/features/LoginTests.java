package org.example.features;

import net.serenitybdd.junit.runners.SerenityParameterizedRunner;
import net.thucydides.junit.annotations.UseTestDataFrom;
import net.thucydides.core.annotations.Managed;
import net.thucydides.core.annotations.Steps;
import org.example.steps.LoginSteps;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.openqa.selenium.WebDriver;

@RunWith(SerenityParameterizedRunner.class)
@UseTestDataFrom("src/test/resources/invalid-logins.csv")
public class LoginTests {

    @Managed(driver = "chrome")
    WebDriver driver;

    @Steps
    LoginSteps login;



    public String username;
    public String password;

    @Test
    public void should_not_login_with_invalid_credentials() {
        login.is_on_login_page();
        login.logs_in_with(username, password);
        login.should_see_error();
    }
}
