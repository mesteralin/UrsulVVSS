package org.example.steps;

import net.serenitybdd.core.annotations.findby.By;
import net.thucydides.core.annotations.Step;
import net.thucydides.core.pages.Pages;
import net.thucydides.core.steps.ScenarioSteps;
import org.openqa.selenium.WebDriver;

import static org.junit.Assert.assertTrue;

public class LoginSteps extends ScenarioSteps {

    public LoginSteps(Pages pages) {
        super(pages);
    }

    public WebDriver getDriver() {
        return getPages().getDriver();
    }

    @Step
    public void is_on_login_page() {
        getDriver().get("https://www.saucedemo.com");
    }

    @Step
    public void logs_in_with(String username, String password) {
        getDriver().findElement(By.id("user-name")).sendKeys(username);
        getDriver().findElement(By.id("password")).sendKeys(password);
        getDriver().findElement(By.id("login-button")).click();
    }

    @Step
    public void should_see_error() {
        assertTrue(getDriver().findElement(By.cssSelector("[data-test='error']")).isDisplayed());
    }

    @Step
    public void should_be_on_inventory_page() {
        assertTrue(getDriver().getCurrentUrl().contains("inventory.html"));
    }
}