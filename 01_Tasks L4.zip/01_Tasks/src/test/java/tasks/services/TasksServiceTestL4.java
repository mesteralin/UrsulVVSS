package tasks.services;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import tasks.model.ArrayTaskList;
import tasks.model.Task;

import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class TasksServiceTestL4 {

    private ArrayTaskList mockRepo;
    private TasksService service;

    private Task task1, task2;

    @BeforeEach
    void setUp() {
        mockRepo = mock(ArrayTaskList.class);
        service = new TasksService(mockRepo);

        task1 = mock(Task.class);
        task2 = mock(Task.class);
    }

    @Test
    void testFilterTasksReturnsCorrectResults() {
        Calendar cal = Calendar.getInstance();
        Date start = cal.getTime();
        cal.add(Calendar.MINUTE, 10);
        Date end = cal.getTime();

        when(task1.nextTimeAfter(start)).thenReturn(new Date(start.getTime() + 5000));
        when(task2.nextTimeAfter(start)).thenReturn(null);

        when(mockRepo.getAll()).thenReturn(Arrays.asList(task1, task2));

        Iterable<Task> result = service.filterTasks(start, end);
        assertTrue(result.iterator().hasNext());
        assertEquals(task1, result.iterator().next());
    }

    @Test
    void testFilterTasksWithNoTasksMatching() {
        Calendar cal = Calendar.getInstance();
        Date start = cal.getTime();
        cal.add(Calendar.MINUTE, 5);
        Date end = cal.getTime();

        when(task1.nextTimeAfter(start)).thenReturn(null);
        when(task2.nextTimeAfter(start)).thenReturn(null);

        when(mockRepo.getAll()).thenReturn(Arrays.asList(task1, task2));

        Iterable<Task> result = service.filterTasks(start, end);
        assertFalse(result.iterator().hasNext());
    }

    @Test
    void testParseFromStringToSeconds() {
        int seconds = service.parseFromStringToSeconds("02:30");
        assertEquals(2 * 3600 + 30 * 60, seconds);
    }
}
