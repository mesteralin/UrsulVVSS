package tasks.model;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import javafx.collections.ObservableList;
import javafx.collections.FXCollections;

import java.util.Arrays;
import java.util.Date;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class TasksOperationsTestL4 {

    private Task task1, task2;
    private Date start, end;
    private TasksOperations tasksOps;

    @BeforeEach
    void setUp() {
        start = new Date(System.currentTimeMillis());
        end = new Date(System.currentTimeMillis() + 10000);

        // Mock task1
        task1 = mock(Task.class);
        when(task1.nextTimeAfter(start)).thenReturn(new Date(start.getTime() + 1000));

        // Mock task2
        task2 = mock(Task.class);
        when(task2.nextTimeAfter(start)).thenReturn(null);

        // Create observable list with both mock tasks
        ObservableList<Task> observableTasks = FXCollections.observableArrayList(Arrays.asList(task1, task2));

        tasksOps = new TasksOperations(observableTasks);
    }

    @Test
    void testIncomingReturnsOnlyValidTask() {
        Iterable<Task> incoming = tasksOps.incoming(start, end);
        List<Task> result = (List<Task>) incoming;

        assertTrue(result.contains(task1));
        assertFalse(result.contains(task2));
    }

    @Test
    void testIncomingWithAllNullNextTimes() {
        when(task1.nextTimeAfter(start)).thenReturn(null);
        when(task2.nextTimeAfter(start)).thenReturn(null);

        Iterable<Task> incoming = tasksOps.incoming(start, end);
        assertFalse(incoming.iterator().hasNext());
    }

    @Test
    void testIncomingWithNextTimeEqualToEnd() {
        Date equalToEnd = new Date(end.getTime());

        when(task1.nextTimeAfter(start)).thenReturn(equalToEnd);

        Iterable<Task> incoming = tasksOps.incoming(start, end);
        List<Task> result = (List<Task>) incoming;

        assertTrue(result.contains(task1));
    }
}
