package tasks.model;

import org.junit.jupiter.api.Test;

import java.util.Calendar;
import java.util.Date;

import static org.junit.jupiter.api.Assertions.*;

public class TaskTestL4 {

    @Test
    public void testNonRepeatedActiveTask_nextTimeAfter() {
        Date time = new Date(System.currentTimeMillis() + 10000);
        Task task = new Task("Test Task", time);
        task.setActive(true);

        Date before = new Date(System.currentTimeMillis());
        assertEquals(time, task.nextTimeAfter(before));
    }

    @Test
    public void testRepeatedActiveTask_nextTimeAfter() {
        Calendar cal = Calendar.getInstance();
        cal.set(2025, Calendar.MAY, 1, 10, 0);
        Date start = cal.getTime();

        cal.set(2025, Calendar.MAY, 1, 10, 30);
        Date end = cal.getTime();

        Task task = new Task("Repeat Task", start, end, 600); // interval 10 min
        task.setActive(true);

        cal.set(2025, Calendar.MAY, 1, 10, 10);
        Date current = cal.getTime();

        Date expected = new Date(start.getTime() + 2 * 600 * 1000); // next time at 10:20
        assertEquals(expected, task.nextTimeAfter(current));
    }

    @Test
    public void testInactiveTask_nextTimeAfterReturnsNull() {
        Date time = new Date(System.currentTimeMillis() + 10000);
        Task task = new Task("Inactive Task", time);
        task.setActive(false);

        Date now = new Date();
        assertNull(task.nextTimeAfter(now));
    }

    @Test
    public void testConstructorValidation() {
        Date future = new Date(System.currentTimeMillis() + 1000);
        assertDoesNotThrow(() -> new Task("Safe Task", future));

        assertThrows(IllegalArgumentException.class, () -> {
            new Task("Invalid", new Date(-1000));
        });

        assertThrows(IllegalArgumentException.class, () -> {
            new Task("Invalid Repeated", new Date(), new Date(), 0);
        });
    }
}
